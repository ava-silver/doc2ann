# doc2ann

Inspired by [com2ann](https://github.com/ilevkivskyi/com2ann), I wanted to create a similar tool for converting docstring comments.


## Usage:

Install the dependencies:
```bash
$ pip install doc2ann
```
Running

```bash
$ doc2ann -a your_file.py
```
