class A:
    def _some_private_method(
        self,
        param1,
        param2,
        param3,
        param4,
    ):
        """A pretty cool method
        Args:
            param1 (str): lorem
            param2 (func): ipsum
            param3 (type): dolor
            param4 (list<str>): sit da amet

        Return:
            (list<things>): some things to return

        """


def foo(x):
    """
    hi mom!
    Args:
        x (bool): woah
    Return:
        list<str>: non parenthesized return type

    """
